// Frontend API configuration
// Set the API base URL in one place for all pages.
// Default: when served over http(s), API_BASE will be derived from current origin by api.js.
// When opening pages via file:// without a dev server, set this to your backend URL.

// Since we're opening HTML files directly without a web server,
// we need to explicitly set the backend URL
window.API_BASE = 'http://localhost:5000/api';

// In production, let api.js derive the base from the current origin
// (leave empty string so it is ignored by api.js)
// window.API_BASE = '';


