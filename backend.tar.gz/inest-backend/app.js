const express = require('express');
const cors = require('cors');

const userRoutes = require('./routes/userRoutes');
const laundryRoutes = require('./routes/laundryRoutes');
const bakerRoutes = require('./routes/bakerRoutes');
const medicalRoutes = require('./routes/medicalRoutes');
const whistleNestRoutes = require('./routes/whistleNestRoutes');

const app = express();

app.use(cors({
  origin: '*', // Allow all origins
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());

// Simple health endpoint for connectivity checks
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.use('/api/users', userRoutes);
app.use('/api/laundry', laundryRoutes);
app.use('/api/bakers', bakerRoutes);
app.use('/api/medicals', medicalRoutes);
app.use('/api/whistlenest', whistleNestRoutes);

module.exports = app;